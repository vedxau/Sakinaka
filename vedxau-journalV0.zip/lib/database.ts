import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)
const DEFAULT_USER_ID = "demo-user"

export interface Trade {
  id: number
  user_id: string
  asset: string
  session: string
  date: string
  setup: string
  entry_timeframe: string
  entry_price: number
  stop_loss: number
  take_profit_1?: number
  take_profit_2?: number
  risk_reward?: number
  result?: "win" | "loss" | "breakeven"
  daily_setup?: string
  confluences?: string
  daily_bias?: string
  setup_details?: string
  screenshots?: string[]
  created_at: string
  updated_at: string
}

export interface TradeFilters {
  asset?: string
  session?: string
  setup?: string
  result?: string
  dateFrom?: string
  dateTo?: string
}

export async function getTrades(userId: string = DEFAULT_USER_ID, filters?: TradeFilters): Promise<Trade[]> {
  const baseQuery = `SELECT * FROM trades WHERE user_id = '${userId}'`
  const conditions: string[] = []

  if (filters?.asset) {
    conditions.push(`asset = '${filters.asset}'`)
  }

  if (filters?.session) {
    conditions.push(`session = '${filters.session}'`)
  }

  if (filters?.setup) {
    conditions.push(`setup = '${filters.setup}'`)
  }

  if (filters?.result) {
    conditions.push(`result = '${filters.result}'`)
  }

  if (filters?.dateFrom) {
    conditions.push(`date >= '${filters.dateFrom}'`)
  }

  if (filters?.dateTo) {
    conditions.push(`date <= '${filters.dateTo}'`)
  }

  const finalQuery =
    conditions.length > 0
      ? `${baseQuery} AND ${conditions.join(" AND ")} ORDER BY date DESC`
      : `${baseQuery} ORDER BY date DESC`

  const result = await sql`${sql.unsafe(finalQuery)}`
  return result as Trade[]
}

export async function createTrade(
  trade: Omit<Trade, "id" | "created_at" | "updated_at" | "user_id"> & { user_id?: string },
): Promise<Trade> {
  const tradeWithUserId = {
    ...trade,
    user_id: trade.user_id || DEFAULT_USER_ID,
  }

  const result = await sql`
    INSERT INTO trades (
      user_id, asset, session, date, setup, entry_timeframe, entry_price,
      stop_loss, take_profit_1, take_profit_2, risk_reward, result,
      daily_setup, confluences, daily_bias, setup_details, screenshots
    ) VALUES (
      ${tradeWithUserId.user_id}, ${tradeWithUserId.asset}, ${tradeWithUserId.session}, ${tradeWithUserId.date}, 
      ${tradeWithUserId.setup}, ${tradeWithUserId.entry_timeframe}, ${tradeWithUserId.entry_price},
      ${tradeWithUserId.stop_loss}, ${tradeWithUserId.take_profit_1}, ${tradeWithUserId.take_profit_2}, 
      ${tradeWithUserId.risk_reward}, ${tradeWithUserId.result}, ${tradeWithUserId.daily_setup}, 
      ${tradeWithUserId.confluences}, ${tradeWithUserId.daily_bias}, ${tradeWithUserId.setup_details}, 
      ${JSON.stringify(tradeWithUserId.screenshots || [])}
    )
    RETURNING *
  `

  return result[0] as Trade
}

export async function getTradeStats(userId: string = DEFAULT_USER_ID) {
  const stats = await sql`
    SELECT 
      COUNT(*) as total_trades,
      COUNT(CASE WHEN result = 'win' THEN 1 END) as wins,
      COUNT(CASE WHEN result = 'loss' THEN 1 END) as losses,
      AVG(CASE WHEN risk_reward IS NOT NULL THEN risk_reward END) as avg_rr,
      MAX(risk_reward) as highest_rr
    FROM trades 
    WHERE user_id = ${userId}
  `

  const setupStats = await sql`
    SELECT 
      setup,
      COUNT(*) as trade_count,
      COUNT(CASE WHEN result = 'win' THEN 1 END) as wins
    FROM trades 
    WHERE user_id = ${userId}
    GROUP BY setup
    ORDER BY wins DESC
    LIMIT 1
  `

  const sessionStats = await sql`
    SELECT 
      session,
      COUNT(*) as trade_count,
      COUNT(CASE WHEN result = 'win' THEN 1 END) as wins
    FROM trades 
    WHERE user_id = ${userId}
    GROUP BY session
    ORDER BY wins DESC
    LIMIT 1
  `

  return {
    totalTrades: Number(stats[0]?.total_trades || 0),
    wins: Number(stats[0]?.wins || 0),
    losses: Number(stats[0]?.losses || 0),
    winRate: stats[0]?.total_trades > 0 ? (Number(stats[0]?.wins || 0) / Number(stats[0]?.total_trades || 1)) * 100 : 0,
    avgRR: Number(stats[0]?.avg_rr || 0),
    highestRR: Number(stats[0]?.highest_rr || 0),
    mostProfitableSetup: setupStats[0]?.setup || "N/A",
    bestSession: sessionStats[0]?.session || "N/A",
  }
}
