-- Fix the trades table foreign key constraint to reference the correct users table
-- and update the user_id column to match the users table id type

-- Drop the existing foreign key constraint
ALTER TABLE trades DROP CONSTRAINT IF EXISTS trades_user_id_fkey;

-- Change user_id column type to integer to match users.id
ALTER TABLE trades ALTER COLUMN user_id TYPE integer USING user_id::integer;

-- Add the correct foreign key constraint
ALTER TABLE trades ADD CONSTRAINT trades_user_id_fkey 
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
