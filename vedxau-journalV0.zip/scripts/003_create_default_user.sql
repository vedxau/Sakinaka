-- Create a default user for demo purposes
INSERT INTO users_sync (id, email, name, created_at, updated_at, raw_json)
VALUES (
  'demo-user-123',
  'demo@vedxaujournal.com',
  'Demo User',
  NOW(),
  NOW(),
  '{"demo": true}'::jsonb
)
ON CONFLICT (id) DO NOTHING;
