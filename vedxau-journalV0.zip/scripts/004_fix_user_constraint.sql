-- Remove foreign key constraint and make user_id nullable for demo purposes
ALTER TABLE trades DROP CONSTRAINT IF EXISTS trades_user_id_fkey;
ALTER TABLE trades ALTER COLUMN user_id DROP NOT NULL;

-- Set a default user_id for existing trades if any
UPDATE trades SET user_id = 'demo-user' WHERE user_id IS NULL;
