-- Insert sample trades for demonstration
INSERT INTO trades (
  user_id, asset, session, date, setup, entry_timeframe, entry_price, 
  stop_loss, take_profit_1, take_profit_2, risk_reward, result, 
  daily_setup, confluences, daily_bias, setup_details
) VALUES 
(
  (SELECT id FROM neon_auth.users_sync LIMIT 1),
  'EUR/USD', 'London', '2024-07-25', 'QML', 'M15', 1.0780, 1.0750, 1.0820, NULL, 1.33, 'win', 'GSD',
  'Daily supply zone, 4H order block, Liquidity sweep.',
  'Aligned with daily bullish bias',
  'Entered on confirmation of sweep and break, managed risk effectively.'
),
(
  (SELECT id FROM neon_auth.users_sync LIMIT 1),
  'GBP/JPY', 'NY', '2024-07-24', 'TJL1', 'H1', 182.50, 182.80, 181.90, NULL, 2.0, 'win', 'RSD',
  'H4 demand zone, liquidity grab confirmation.',
  'Bearish daily bias confirmed',
  'Perfect entry at demand zone with strong momentum.'
),
(
  (SELECT id FROM neon_auth.users_sync LIMIT 1),
  'XAU/USD', 'Asian', '2024-07-23', 'SBR', 'M5', 2320.00, 2318.50, 2326.00, NULL, 4.0, 'win', 'FBR',
  'Daily resistance break, volume confirmation.',
  'Bullish continuation expected',
  'Strong breakout with high volume, excellent R:R achieved.'
),
(
  (SELECT id FROM neon_auth.users_sync LIMIT 1),
  'USD/CAD', 'NY', '2024-07-22', 'RBS', 'D1', 1.3650, 1.3590, 1.3800, NULL, 2.5, 'loss', 'GSD',
  'Weekly support level, oversold conditions.',
  'Mixed signals on daily',
  'Entry was premature, market continued lower than expected.'
),
(
  (SELECT id FROM neon_auth.users_sync LIMIT 1),
  'AUD/USD', 'NY', '2024-07-21', 'DB', 'H4', 0.6700, 0.6720, 0.6650, NULL, 1.5, 'win', 'RSD',
  'Double bottom formation, RSI divergence.',
  'Bullish reversal pattern',
  'Clean double bottom with divergence, textbook setup.'
);
