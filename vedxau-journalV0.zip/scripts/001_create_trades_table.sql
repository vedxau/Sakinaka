-- Create trades table for storing trading journal entries
CREATE TABLE IF NOT EXISTS trades (
  id SERIAL PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES neon_auth.users_sync(id),
  asset VARCHAR(20) NOT NULL,
  session VARCHAR(20) NOT NULL,
  date DATE NOT NULL,
  setup VARCHAR(50) NOT NULL,
  entry_timeframe VARCHAR(10) NOT NULL,
  entry_price DECIMAL(10, 5) NOT NULL,
  stop_loss DECIMAL(10, 5) NOT NULL,
  take_profit_1 DECIMAL(10, 5),
  take_profit_2 DECIMAL(10, 5),
  risk_reward DECIMAL(5, 2),
  result VARCHAR(10) CHECK (result IN ('win', 'loss', 'breakeven')),
  daily_setup VARCHAR(50),
  confluences TEXT,
  daily_bias TEXT,
  setup_details TEXT,
  screenshots JSONB DEFAULT '[]',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_trades_user_id ON trades(user_id);
CREATE INDEX IF NOT EXISTS idx_trades_date ON trades(date);
CREATE INDEX IF NOT EXISTS idx_trades_asset ON trades(asset);
CREATE INDEX IF NOT EXISTS idx_trades_session ON trades(session);
CREATE INDEX IF NOT EXISTS idx_trades_setup ON trades(setup);
