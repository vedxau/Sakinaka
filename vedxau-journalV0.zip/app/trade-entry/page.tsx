"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, X } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface TradeFormData {
  asset: string
  session: string
  date: string
  setup: string
  entryTF: string
  entryPrice: string
  stopLoss: string
  takeProfit1: string
  takeProfit2: string
  rr: string
  confluences: string
  dailyBias: string
  setupDetails: string
}

export default function TradeEntryPage() {
  const router = useRouter()
  const [formData, setFormData] = useState<TradeFormData>({
    asset: "",
    session: "",
    date: "",
    setup: "",
    entryTF: "",
    entryPrice: "",
    stopLoss: "",
    takeProfit1: "",
    takeProfit2: "",
    rr: "",
    confluences: "",
    dailyBias: "",
    setupDetails: "",
  })

  const [uploadedImages, setUploadedImages] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (field: keyof TradeFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (files) {
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      setUploadedImages((prev) => [...prev, ...newImages])
    }
  }

  const removeImage = (index: number) => {
    setUploadedImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const tradeData = {
        asset: formData.asset,
        session: formData.session,
        date: formData.date,
        setup: formData.setup,
        entry_timeframe: formData.entryTF,
        entry_price: Number.parseFloat(formData.entryPrice),
        stop_loss: Number.parseFloat(formData.stopLoss),
        take_profit_1: formData.takeProfit1 ? Number.parseFloat(formData.takeProfit1) : null,
        take_profit_2: formData.takeProfit2 ? Number.parseFloat(formData.takeProfit2) : null,
        risk_reward: formData.rr ? Number.parseFloat(formData.rr) : null,
        confluences: formData.confluences,
        daily_bias: formData.dailyBias,
        setup_details: formData.setupDetails,
        screenshots: uploadedImages,
      }

      const response = await fetch("/api/trades", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(tradeData),
      })

      if (response.ok) {
        router.push("/trade-log")
      } else {
        console.error("Failed to save trade")
        alert("Failed to save trade. Please try again.")
      }
    } catch (error) {
      console.error("Error saving trade:", error)
      alert("An error occurred while saving the trade.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="flex h-16 items-center px-6">
          <div className="text-2xl font-bold text-primary">VedXau Journal</div>
          <nav className="ml-8 flex items-center space-x-6">
            <Link href="/dashboard">
              <Button variant="ghost" className="text-muted-foreground">
                Dashboard
              </Button>
            </Link>
            <Link href="/trade-log">
              <Button variant="ghost" className="text-muted-foreground">
                Trade Log
              </Button>
            </Link>
          </nav>
          <div className="ml-auto">
            <Button variant="outline" asChild>
              <Link href="/trade-log">Back to Trade Log</Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Trade Entry Details</h1>
          <div className="flex items-center gap-4 mt-2">
            <span className="text-muted-foreground">Dashboard</span>
            <span className="text-muted-foreground">Trade Log</span>
            <Badge variant="secondary">30</Badge>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Basics</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="asset">Asset</Label>
                <Input
                  id="asset"
                  placeholder="e.g. XAUUSD"
                  value={formData.asset}
                  onChange={(e) => handleInputChange("asset", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="session">Session</Label>
                <Select value={formData.session} onValueChange={(value) => handleInputChange("session", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select session" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="London Open">London Open</SelectItem>
                    <SelectItem value="NY">NY</SelectItem>
                    <SelectItem value="Asian">Asian</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange("date", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="setup">Setup</Label>
                <Select value={formData.setup} onValueChange={(value) => handleInputChange("setup", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select setup" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="QML">QML</SelectItem>
                    <SelectItem value="TJL1">TJL1</SelectItem>
                    <SelectItem value="TJL2">TJL2</SelectItem>
                    <SelectItem value="SBR">SBR</SelectItem>
                    <SelectItem value="RBS">RBS</SelectItem>
                    <SelectItem value="DB">DB</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Entries/Exits</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="entryTF">Entry TF</Label>
                  <Select value={formData.entryTF} onValueChange={(value) => handleInputChange("entryTF", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select timeframe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M1">M1</SelectItem>
                      <SelectItem value="M5">M5</SelectItem>
                      <SelectItem value="M15">M15</SelectItem>
                      <SelectItem value="M30">M30</SelectItem>
                      <SelectItem value="H1">H1</SelectItem>
                      <SelectItem value="H4">H4</SelectItem>
                      <SelectItem value="D1">D1</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="entryPrice">Entry Price</Label>
                  <Input
                    id="entryPrice"
                    placeholder="2050.3"
                    value={formData.entryPrice}
                    onChange={(e) => handleInputChange("entryPrice", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rr">R:R</Label>
                  <Input
                    id="rr"
                    placeholder="2.14"
                    value={formData.rr}
                    onChange={(e) => handleInputChange("rr", e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="stopLoss">Stop Loss (SL)</Label>
                  <Input
                    id="stopLoss"
                    placeholder="2048.1"
                    value={formData.stopLoss}
                    onChange={(e) => handleInputChange("stopLoss", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="takeProfit1">Take Profit 1 (TP1)</Label>
                  <Input
                    id="takeProfit1"
                    placeholder="2055"
                    value={formData.takeProfit1}
                    onChange={(e) => handleInputChange("takeProfit1", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="takeProfit2">Take Profit 2 (TP2)</Label>
                  <Input
                    id="takeProfit2"
                    placeholder="2060"
                    value={formData.takeProfit2}
                    onChange={(e) => handleInputChange("takeProfit2", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confluences">Confluences</Label>
                <Textarea
                  id="confluences"
                  placeholder="Daily supply zone, 4H order block, Liquidity sweep."
                  value={formData.confluences}
                  onChange={(e) => handleInputChange("confluences", e.target.value)}
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="dailyBias">DAILY BIAS</Label>
                <Input
                  id="dailyBias"
                  placeholder="Aligned with daily bullish bias"
                  value={formData.dailyBias}
                  onChange={(e) => handleInputChange("dailyBias", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="setupDetails">SETUP DETAILS</Label>
                <Textarea
                  id="setupDetails"
                  placeholder="Entered on confirmation of sweep and break, missed optimal re-entry by a few pips. Managed risk effectively, exited TP1 at strong resistance. TP2 not hit, closed manually."
                  value={formData.setupDetails}
                  onChange={(e) => handleInputChange("setupDetails", e.target.value)}
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Screenshots</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <label htmlFor="image-upload" className="cursor-pointer">
                    <div className="flex flex-col items-center gap-2">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                        <Plus className="h-6 w-6 text-primary" />
                      </div>
                      <div className="text-sm font-medium">Add Image</div>
                      <div className="text-xs text-muted-foreground">Click to upload screenshots</div>
                    </div>
                  </label>
                </div>

                {uploadedImages.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {uploadedImages.map((image, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={image || "/placeholder.svg"}
                          alt={`Screenshot ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg border"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button type="submit" size="lg" className="px-8" disabled={isSubmitting}>
              {isSubmitting ? "Saving..." : "Save Trade"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
