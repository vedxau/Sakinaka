export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 w-full max-w-2xl border border-white/20">
        <h1 className="text-3xl font-bold text-white mb-6">Terms of Service</h1>
        <div className="text-white/90 space-y-4">
          <p>Welcome to VedXau Journal. By using our service, you agree to these terms.</p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">1. Service Description</h2>
          <p>
            VedXau Journal is a trading journal application that helps you track and analyze your trading performance.
          </p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">2. User Responsibilities</h2>
          <p>
            You are responsible for maintaining the confidentiality of your account and for all activities under your
            account.
          </p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">3. Data Usage</h2>
          <p>We collect and use your trading data solely to provide our journaling services and analytics.</p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">4. Limitation of Liability</h2>
          <p>
            VedXau Journal is provided "as is" without warranties. We are not liable for trading decisions made using
            our platform.
          </p>
        </div>
        <div className="mt-8">
          <a href="/signup" className="text-purple-300 hover:text-purple-200 underline">
            ← Back to Sign Up
          </a>
        </div>
      </div>
    </div>
  )
}
