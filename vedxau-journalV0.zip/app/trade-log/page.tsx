"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Filter, ImageIcon } from "lucide-react"
import Link from "next/link"
import type { Trade } from "@/lib/database"

export default function TradeLogPage() {
  const [filters, setFilters] = useState({
    date: "",
    asset: "",
    session: "",
    setup: "",
    result: "",
  })

  const [trades, setTrades] = useState<Trade[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTrades = async () => {
      try {
        const params = new URLSearchParams()
        Object.entries(filters).forEach(([key, value]) => {
          if (value) params.append(key, value)
        })

        const response = await fetch(`/api/trades?${params}`)
        if (response.ok) {
          const data = await response.json()
          setTrades(data)
        }
      } catch (error) {
        console.error("Failed to fetch trades:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTrades()
  }, [filters])

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const getResultBadge = (result: string) => {
    if (result === "win") {
      return <div className="w-3 h-3 bg-green-500 rounded-full"></div>
    }
    return <div className="w-3 h-3 bg-red-500 rounded-full"></div>
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="flex h-16 items-center px-6">
          <div className="text-2xl font-bold text-primary">VedXau Journal</div>
          <nav className="ml-8 flex items-center space-x-6">
            <Link href="/dashboard">
              <Button variant="ghost" className="text-muted-foreground">
                Dashboard
              </Button>
            </Link>
            <Button variant="ghost" className="text-primary font-medium">
              Trade Log
            </Button>
          </nav>
          <div className="ml-auto">
            <Link href="/trade-entry">
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Trade
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Page Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Trade Log</h1>
            <div className="flex items-center gap-4 mt-2">
              <span className="text-muted-foreground">Dashboard</span>
              <span className="text-muted-foreground">Trade Log</span>
              <Badge variant="secondary">{trades.length}</Badge>
            </div>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filters:
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Date</label>
                <Input
                  placeholder="YYYY-MM-DD"
                  value={filters.date}
                  onChange={(e) => handleFilterChange("date", e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Asset</label>
                <Input
                  placeholder="e.g. EUR/USD"
                  value={filters.asset}
                  onChange={(e) => handleFilterChange("asset", e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Session</label>
                <Select value={filters.session} onValueChange={(value) => handleFilterChange("session", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Sessions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sessions</SelectItem>
                    <SelectItem value="London">London</SelectItem>
                    <SelectItem value="NY">NY</SelectItem>
                    <SelectItem value="Asian">Asian</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Setup</label>
                <Select value={filters.setup} onValueChange={(value) => handleFilterChange("setup", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Setups" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Setups</SelectItem>
                    <SelectItem value="QML">QML</SelectItem>
                    <SelectItem value="TJL1">TJL1</SelectItem>
                    <SelectItem value="TJL2">TJL2</SelectItem>
                    <SelectItem value="SBR">SBR</SelectItem>
                    <SelectItem value="RBS">RBS</SelectItem>
                    <SelectItem value="DB">DB</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Result</label>
                <Select value={filters.result} onValueChange={(value) => handleFilterChange("result", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Results" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Results</SelectItem>
                    <SelectItem value="win">Win</SelectItem>
                    <SelectItem value="loss">Loss</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Trade Log Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Asset</TableHead>
                    <TableHead>Entry TF</TableHead>
                    <TableHead>Entry/SL/TP</TableHead>
                    <TableHead>R:R</TableHead>
                    <TableHead>Result</TableHead>
                    <TableHead>Session</TableHead>
                    <TableHead>Setup</TableHead>
                    <TableHead>Daily Setup</TableHead>
                    <TableHead>Images</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={10} className="text-center py-8">
                        Loading trades...
                      </TableCell>
                    </TableRow>
                  ) : trades.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={10} className="text-center py-8">
                        No trades found
                      </TableCell>
                    </TableRow>
                  ) : (
                    trades.map((trade) => (
                      <TableRow key={trade.id} className="hover:bg-muted/50">
                        <TableCell className="font-medium">{trade.date}</TableCell>
                        <TableCell>{trade.asset}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{trade.entry_timeframe}</Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {trade.entry_price} / {trade.stop_loss} / {trade.take_profit_1}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">1:{trade.risk_reward?.toFixed(1) || "N/A"}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">{getResultBadge(trade.result || "")}</div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{trade.session}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-primary/10 text-primary hover:bg-primary/20">{trade.setup}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{trade.daily_setup || "N/A"}</Badge>
                        </TableCell>
                        <TableCell>
                          {trade.screenshots && trade.screenshots.length > 0 ? (
                            <ImageIcon className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <span className="text-muted-foreground text-sm">N/A</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Add Trade Button */}
        <div className="flex justify-center">
          <Link href="/trade-entry">
            <Button size="lg" className="gap-2">
              <div className="w-6 h-6 bg-primary-foreground rounded-full flex items-center justify-center">
                <Plus className="h-4 w-4 text-primary" />
              </div>
              Add New Trade
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
