"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Line, LineChart, Bar, BarChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Plus, TrendingUp, Target, Clock, BarChart3, LogOut } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

// Mock data for charts
const equityData = [
  { month: "Jan", value: 1000 },
  { month: "Feb", value: 1500 },
  { month: "Mar", value: 2200 },
  { month: "Apr", value: 1800 },
  { month: "May", value: 2800 },
  { month: "Jun", value: 3200 },
  { month: "Jul", value: 2900 },
  { month: "Aug", value: 3800 },
  { month: "Sep", value: 4200 },
  { month: "Oct", value: 3900 },
  { month: "Nov", value: 4600 },
  { month: "Dec", value: 5000 },
]

const setupData = [
  { setup: "QML", profit: 320, trades: 50 },
  { setup: "TJL1", profit: 280, trades: 35 },
  { setup: "TJL2", profit: 190, trades: 28 },
  { setup: "SBR", profit: 150, trades: 22 },
  { setup: "RBS", profit: 120, trades: 18 },
  { setup: "GSD", profit: 90, trades: 15 },
]

// Mock heatmap data
const heatmapData = [
  [1, 0, 1, -1, 1, 0, 1],
  [1, 1, 0, 1, -1, 1, 0],
  [-1, 1, 1, 0, 1, 1, -1],
  [1, 0, -1, 1, 1, 0, 1],
  [0, 1, 1, -1, 0, 1, 1],
]

const newsData = [
  {
    time: "10:00 AM",
    impact: "High",
    country: "US",
    event: "US Inflation Data Release Affects Market Outlook",
  },
  {
    time: "08:30 AM",
    impact: "High",
    country: "EU",
    event: "ECB President Speech on Monetary Policy",
  },
  {
    time: "02:00 PM",
    impact: "Medium",
    country: "JP",
    event: "Bank of Japan Discusses Yield Curve Control",
  },
  {
    time: "11:00 AM",
    impact: "Medium",
    country: "CA",
    event: "Canada Employment Change Report Released",
  },
]

export default function DashboardPage() {
  const router = useRouter()
  const [stats, setStats] = useState({
    totalTrades: 0,
    wins: 0,
    losses: 0,
    winRate: 0,
    avgRR: 0,
    highestRR: 0,
    mostProfitableSetup: "N/A",
    bestSession: "N/A",
  })

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch("/api/stats")
        if (response.ok) {
          const data = await response.json()
          setStats(data)
        }
      } catch (error) {
        console.error("Failed to fetch stats:", error)
      }
    }

    fetchStats()
  }, [])

  const getHeatmapColor = (value: number) => {
    if (value === 1) return "bg-green-500"
    if (value === -1) return "bg-red-500"
    return "bg-gray-200"
  }

  const getImpactColor = (impact: string) => {
    if (impact === "High") return "bg-red-100 text-red-800"
    if (impact === "Medium") return "bg-yellow-100 text-yellow-800"
    return "bg-green-100 text-green-800"
  }

  const handleLogout = () => {
    // Clear user session
    localStorage.removeItem("user")
    // Redirect to login page
    router.push("/login")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="flex h-16 items-center px-6">
          <div className="text-2xl font-bold text-primary">VedXau Journal</div>
          <nav className="ml-8 flex items-center space-x-6">
            <Button variant="ghost" className="text-primary font-medium">
              Dashboard
            </Button>
            <Link href="/trade-log">
              <Button variant="ghost" className="text-muted-foreground">
                Trade Log
              </Button>
            </Link>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <Link href="/trade-entry">
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Trade
              </Button>
            </Link>
            <Button variant="outline" onClick={handleLogout} className="gap-2 bg-transparent">
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Overview</p>
        </div>

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Most Profitable Setup</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{stats.mostProfitableSetup}</div>
              <p className="text-xs text-muted-foreground">Based on win rate analysis</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Best Performing Session</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{stats.bestSession}</div>
              <p className="text-xs text-muted-foreground">Highest win rate session</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Highest R:R</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">1:{stats.highestRR.toFixed(1)}</div>
              <p className="text-xs text-muted-foreground">Best risk-reward ratio</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Trades</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalTrades}</div>
              <p className="text-xs text-muted-foreground">All time trades</p>
            </CardContent>
          </Card>
        </div>

        {/* Performance Overview */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Overview</CardTitle>
            <CardDescription>Key trading metrics at a glance.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.winRate.toFixed(1)}%</div>
                <div className="text-sm text-muted-foreground">Win Rate</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">1:{stats.avgRR.toFixed(1)}</div>
                <div className="text-sm text-muted-foreground">Avg R:R</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">+$12,345.78</div>
                <div className="text-sm text-muted-foreground">Net P&L</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">1.8</div>
                <div className="text-sm text-muted-foreground">Expectancy</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">4h 30m</div>
                <div className="text-sm text-muted-foreground">Avg Hold Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">Analytics</div>
                <div className="text-sm text-muted-foreground">30</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Equity Curve */}
          <Card>
            <CardHeader>
              <CardTitle>Equity Curve</CardTitle>
              <CardDescription>Cumulative Profit and Loss over time.</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  value: {
                    label: "P&L",
                    color: "hsl(var(--primary))",
                  },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={equityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#8b5cf6"
                      strokeWidth={3}
                      dot={{ fill: "#8b5cf6", strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6, stroke: "#8b5cf6", strokeWidth: 2, fill: "#ffffff" }}
                      connectNulls={true}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Setup Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>Setup Comparison</CardTitle>
              <CardDescription>Performance breakdown by trading setup.</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  profit: {
                    label: "Profit",
                    color: "hsl(var(--chart-2))",
                  },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={setupData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="setup" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="profit" fill="var(--color-chart-2)" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Daily Results Heatmap */}
          <Card>
            <CardHeader>
              <CardTitle>Daily Results Heatmap</CardTitle>
              <CardDescription>Visual summary of daily trading outcomes.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Sun</span>
                  <span>Mon</span>
                  <span>Tue</span>
                  <span>Wed</span>
                  <span>Thu</span>
                  <span>Fri</span>
                  <span>Sat</span>
                </div>
                {heatmapData.map((week, weekIndex) => (
                  <div key={weekIndex} className="flex gap-1">
                    {week.map((day, dayIndex) => (
                      <div
                        key={dayIndex}
                        className={`w-8 h-8 rounded ${getHeatmapColor(day)} flex items-center justify-center text-xs font-medium text-white`}
                      >
                        {weekIndex * 7 + dayIndex + 1}
                      </div>
                    ))}
                  </div>
                ))}
                <div className="flex items-center gap-4 mt-4 text-xs">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-green-500 rounded"></div>
                    <span>Win</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-red-500 rounded"></div>
                    <span>Loss</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-gray-200 rounded"></div>
                    <span>No Trade</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Market Pulse */}
          <Card>
            <CardHeader>
              <CardTitle>Market Pulse</CardTitle>
              <CardDescription>Stay updated with critical market events.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {newsData.map((news, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                    <div className="text-sm font-medium text-muted-foreground min-w-[60px]">{news.time}</div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge className={getImpactColor(news.impact)} variant="secondary">
                          {news.impact}
                        </Badge>
                        <Badge variant="outline">{news.country}</Badge>
                      </div>
                      <p className="text-sm">{news.event}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
