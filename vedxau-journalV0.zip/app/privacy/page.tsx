export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 w-full max-w-2xl border border-white/20">
        <h1 className="text-3xl font-bold text-white mb-6">Privacy Policy</h1>
        <div className="text-white/90 space-y-4">
          <p>
            Your privacy is important to us. This policy explains how we collect, use, and protect your information.
          </p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">1. Information We Collect</h2>
          <p>We collect trading data, account information, and usage analytics to provide our services.</p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">2. How We Use Your Information</h2>
          <p>Your information is used to provide trading analytics, maintain your account, and improve our services.</p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">3. Data Security</h2>
          <p>We implement industry-standard security measures to protect your data from unauthorized access.</p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">4. Data Sharing</h2>
          <p>We do not sell or share your personal trading data with third parties without your consent.</p>
          <h2 className="text-xl font-semibold text-white mt-6 mb-3">5. Contact Us</h2>
          <p>If you have questions about this privacy policy, please contact us at privacy@vedxaujournal.com</p>
        </div>
        <div className="mt-8">
          <a href="/signup" className="text-purple-300 hover:text-purple-200 underline">
            ← Back to Sign Up
          </a>
        </div>
      </div>
    </div>
  )
}
