import { type NextRequest, NextResponse } from "next/server"
import { getTradeStats } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const userId = "demo-user-123" // Matches the user created in the database

    const stats = await getTradeStats(userId)
    return NextResponse.json(stats)
  } catch (error) {
    console.error("Error fetching stats:", error)

    if (error instanceof Error && error.message.includes('relation "trades" does not exist')) {
      // Return default stats when table doesn't exist
      const defaultStats = {
        totalTrades: 0,
        winRate: 0,
        avgRiskReward: 0,
        netPnl: 0,
        expectancy: 0,
        avgHoldTime: "0h 0m",
        mostProfitableSetup: { setup: "N/A", profit: 0, trades: 0 },
        bestSession: { session: "N/A", pnl: 0 },
        highestRR: { rr: 0, tradeId: null },
      }
      return NextResponse.json(defaultStats)
    }

    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 })
  }
}
