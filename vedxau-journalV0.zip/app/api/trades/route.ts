import { type NextRequest, NextResponse } from "next/server"
import { getTrades, createTrade, type TradeFilters } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const userSession = request.headers.get("authorization")
    if (!userSession) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userData = JSON.parse(userSession)
    const userId = userData.id

    const { searchParams } = new URL(request.url)
    const filters: TradeFilters = {
      asset: searchParams.get("asset") || undefined,
      session: searchParams.get("session") || undefined,
      setup: searchParams.get("setup") || undefined,
      result: searchParams.get("result") || undefined,
      dateFrom: searchParams.get("dateFrom") || undefined,
      dateTo: searchParams.get("dateTo") || undefined,
    }

    const trades = await getTrades(userId, filters)
    return NextResponse.json(trades)
  } catch (error) {
    console.error("Error fetching trades:", error)

    if (error instanceof Error && error.message.includes('relation "trades" does not exist')) {
      // Return empty array when table doesn't exist
      return NextResponse.json([])
    }

    return NextResponse.json({ error: "Failed to fetch trades" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const userSession = request.headers.get("authorization")
    if (!userSession) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userData = JSON.parse(userSession)
    const userId = userData.id

    const trade = await createTrade({
      ...body,
      user_id: userId,
    })

    return NextResponse.json(trade)
  } catch (error) {
    console.error("Error creating trade:", error)

    if (error instanceof Error && error.message.includes('relation "trades" does not exist')) {
      return NextResponse.json(
        {
          error: "Database not initialized. Please run the setup scripts first.",
        },
        { status: 503 },
      )
    }

    return NextResponse.json({ error: "Failed to create trade" }, { status: 500 })
  }
}
