import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import bcrypt from "bcryptjs"

const sql = neon(process.env.DATABASE_URL!)

export async function POST(request: NextRequest) {
  try {
    const { email, password, name } = await request.json()

    if (!email || !password || !name) {
      return NextResponse.json({ error: "Email, password, and name are required" }, { status: 400 })
    }

    const existingUser = await sql`
      SELECT id FROM public.users 
      WHERE email = ${email}
    `

    if (existingUser.length > 0) {
      return NextResponse.json({ error: "User already exists with this email" }, { status: 409 })
    }

    const hashedPassword = await bcrypt.hash(password, 12)

    const newUser = await sql`
      INSERT INTO public.users (name, email, password_hash, created_at, updated_at)
      VALUES (
        ${name},
        ${email}, 
        ${hashedPassword},
        NOW(),
        NOW()
      )
      RETURNING id, email, name
    `

    return NextResponse.json(
      {
        message: "User created successfully",
        user: { id: newUser[0].id, email: newUser[0].email, name: newUser[0].name },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
  }
}
